let fields=[];

function addField(){

let type=document.getElementById("fieldType").value;

fields.push({type:type});

displayFields();

}

function displayFields(){

let container=document.getElementById("fields");

container.innerHTML="";

fields.forEach(field=>{

container.innerHTML+=`<p>${field.type}</p>`;

});

}

function saveForm(){

fetch("/create-form",{

method:"POST",

headers:{
"Content-Type":"application/json"
},

body:JSON.stringify({

title:document.getElementById("title").value,
fields:fields

})

})

}